                                 URG Setting Tool IP Instruction Manual

                                                                                                    2014/01/28
                                     Hokuyo Automatic Co.,Ltd.

1.Revision History
  2014/1/28 First Release

2.Package Contents
  URG_Setting_Tool_IP.exe		: Application software
  QtGui4.dll				: Necessary library for the operation of the application
  QtCore4.dll				: Necessary library for the operation of the application
  libgcc_s_dw2-1.dll		: Necessary library for the operation of the application
  libstdc++-6.dll			: Necessary library for the operation of the application
  mingwm10.dll				: Necessary library for the operation of the application

3.Working Environment
  Windows XP / 7 / 8

4.Starting the Application
  Double click on URG_setting_tool_IP.exe to start the application.

5.Connecting to URG sensor
  After starting the application (as explained above), connect to the sensor by pushing the "Connect" button.

6.IP Address Setting Function
  Specify the desired IP address, subnet mask and default gateway address. Then push the "Set IP Address" button to
  apply changes. The specified settings will take effect and the URG sensor restarts.

7.Others
  All information in this instruction manual is subject to change without any notice.
  The product names,company name mentioned are trademarks or registered trademarks of their respective companies.

