unzip openssh-$ROS_DISTRO.zip; cd openssh-$ROS_DISTRO; ./install.sh; cd ..; rm -r openssh-$ROS_DISTRO;

if [ -d "~/workspaces/hitrobot/dbparam" ]; then
    ROS_USER_DBPARAM=true;
else
    ROS_USER_DBPARAM=false;
    mv ./dbparam  ~/workspaces/hitrobot/dbparam;
    cp -f ~/catkin_ws/install/share/bringup/param/map* ~/workspaces/hitrobot/dbparam;
    sed -i -e "s/image:.*/image: map.pgm/" ~/workspaces/hitrobot/dbparam/map.yaml;
    sed -i -e "s/image:.*/image: map_edit.pgm/" ~/workspaces/hitrobot/dbparam/map_edit.yaml;

    sed -i -e "s/devel\/setup.bash/base.sh/" ~/.bashrc;
    _TTYS=/dev/`dmesg | awk '/ttyS/{print $4}'`;
    if [[ $_TTYS == "/dev/ttyS4" ]]; then
        echo "source ~/catkin_ws/base.sh" >> /etc/profile;
    else
        _TTYS=/dev/ttyS2;
    fi;
    echo 'SUBSYSTEM=="tty", ENV{DEVNAME}=="'$_TTYS'", SYMLINK+="ttySx"' | sudo tee -a /etc/udev/rules.d/70-persistent-tty.rules
    unset _TTYS;

    echo 'hitrobot:343' | sudo chpasswd;
fi;

unzip release-$ROS_DISTRO.zip; release-$ROS_DISTRO/install/share/bringup/shell/update-offline.sh; rm -r release-$ROS_DISTRO;
