find ~/.ros/log/* -mtime +7 -exec rm -rf {} \;
