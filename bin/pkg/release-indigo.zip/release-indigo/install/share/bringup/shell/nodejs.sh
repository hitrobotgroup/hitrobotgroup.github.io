cd ~/catkin_ws/www/server;
node server.js;