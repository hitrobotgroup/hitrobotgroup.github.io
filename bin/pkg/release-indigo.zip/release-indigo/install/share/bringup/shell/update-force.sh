cd ~/workspaces/hitrobot/release;
git reset --hard HEAD^;
source ~/catkin_ws/base.sh;
roscd bringup;
source shell/update.sh;
