rm -rf ~/workspaces/hitrobot/release;
mv ./release-$ROS_DISTRO ~/workspaces/hitrobot/release;
